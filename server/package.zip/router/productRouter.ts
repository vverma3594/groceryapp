import express, { response } from "express";


const productRouter: express.Router = express.Router();

/*
    1. INFO : READ all the Products Info
       URL : http://127.0.0.1:5000/api/products
       METHOD : GET
       FIELDS : no-fields
 */
productRouter.get('/products', (request:express.Request,response:express.Response)=>{
    response.status(200).json({msg:'Get all product'})
})  


export default productRouter;